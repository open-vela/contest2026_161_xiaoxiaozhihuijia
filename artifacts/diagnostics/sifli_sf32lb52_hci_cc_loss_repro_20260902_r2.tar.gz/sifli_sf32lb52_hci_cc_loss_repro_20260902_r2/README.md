# SF32LB52 intermittent missing HCI command completion reproduction

This package documents an intermittent SF32LB52 LCPU Bluetooth controller failure observed with silicon `REVID=0x03`. This revision selects the legacy full RAM LCPU image plus legacy patch path; it does **not** use the Rev-B ROM controller patch.

After the second connect/disconnect cycle, the HCPU publishes `LE Set Extended Advertising Parameters` (`0x2036`) and the LCPU consumes the shared TX ring entry. For approximately ten seconds, the shared RX ring publishes no new bytes: producer/consumer indices and the Adapter mailbox, worker, drain, copied-byte, callback, complete-H4, and forward counters remain unchanged. ZBlue then times out waiting for the genuine Command Complete or Command Status event.

The evidence localizes the failure to the opaque LCPU/controller interval after TX consumption and before RX publication. It does not prove that the `0x2036` command handler itself is necessarily defective. Independent missing replies have also been observed for `0x1001`, `0x2037`, and `0x2038`.

The included firmware is diagnostic-only. It does not retry commands, synthesize completions, alter command credit or semaphores, reset either CPU, or implement automatic recovery.

## Revision 2 serial evidence

Revision 2 adds `serial/two_connect_disconnect_cycles_user_transcription.txt`, copied byte-for-byte from the text file manually uploaded by the user to the Linux host. It contains the controller identity output, two connection/disconnection cycles, the successful first advertising recovery, the second `0x2036` missing reply, the no-progress RX snapshot, and the timeout/fatal context.

This file is a user-provided Codex-conversation serial transcription. It is not a byte-for-byte UART capture exported directly by serial terminal software. The original UART capture remains outstanding evidence and the transcription must not be represented as an original capture. See `serial/provenance_r2.md`.

The earlier `serial/two_connect_disconnect_cycles.log` remains in the package as the r1 summarized transcription for provenance continuity.

See `vendor_request.md` for the requested SiFli assistance and `reproduction/steps.txt` for the minimal reproduction.
