# Request for SiFli controller assistance

## Target identity

- SF32LB52 silicon REVID: `0x03`
- Active controller path: legacy full RAM LCPU image plus legacy patch
- Boot address: `0x20400000`
- Image length: 5664 bytes
- Patch address: `0x20406000`
- Patch length: 8096 bytes
- Rev-B ROM patch active: no
- HCI version/revision: `0x0c` / `0x0200`
- LMP version/subversion: `0x0c` / `0x024e`
- Manufacturer: `0x0a4c`

## Failure

After the second controlled connect/disconnect cycle, the HCPU publishes HCI `0x2036` and observes that the LCPU consumes the shared TX-ring entry. During the following approximately ten seconds, the shared RX producer and consumer mirrors do not advance. Adapter mailbox, worker, drain, copied-byte and callback counters remain unchanged, as do BTH4 complete-frame and forward counters. No genuine Command Complete or Command Status reaches the Host, so the existing synchronous wait times out.

Both preceding `0x203c` Remove Advertising Set commands complete successfully, and the first advertising recreation completes `0x2036`, `0x2037`, and `0x2038`. Missing replies have also occurred independently for `0x1001`, `0x2037`, and `0x2038`, so the evidence does not establish that the `0x2036` handler alone is necessarily defective.

Revision 2 includes the complete user-uploaded Codex-conversation serial transcription as `serial/two_connect_disconnect_cycles_user_transcription.txt`, with its source and SHA-256 recorded in `serial/provenance_r2.md`. This transcription is not a direct byte-for-byte export from UART capture software. The original UART capture remains requested and must not be inferred from or conflated with the transcription.

## Requested information

Please provide:

1. The exact version/build identity corresponding to the supplied REVID `0x03` legacy LCPU image and patch hashes.
2. Known issues involving intermittent loss of HCI Command Complete/Status, shared IPC publication, or Extended Advertising set reuse.
3. A trace-enabled legacy LCPU image/patch capable of recording HCI command dispatch, command completion generation, and HCPU RX-ring publication without changing Host command semantics.
4. A vendor-supported corrected image/patch, if available, together with compatibility and rollback guidance for REVID `0x03`.
5. Confirmation whether the original UART capture or any additional controller-side reproduction metadata is required beyond the included user transcription, ELF, map, configuration, hashes, and diagnostic patch.

No Host-side completion is synthesized in this reproduction, and no retry, semaphore manipulation, command-credit adjustment, HCI Reset, or automatic LCPU restart is used.
