# Revision 2 serial transcription provenance

- Source: serial text transcription from the Codex conversation, manually uploaded by the user to the Linux host.
- Upload path: `/vdb/huangshan-motion-game-clean.20260901/pasted-text.txt`
- Package copy: `serial/two_connect_disconnect_cycles_user_transcription.txt`
- SHA-256: `3a3d6ad15463feea6b69d5acf4c5c8a70f398e15ed4c4260406d96652ac4e20d`
- Copy time: `2026-09-03 09:31:51.259278913 +0800`
- Copied size: 24,738 bytes
- Byte comparison against the uploaded file at copy time: identical

The transcription contains controller identity logs, two connection/disconnection cycles, successful first advertising recovery, the second recovery's `0x2036` missing reply, an RX snapshot showing no progress, and the resulting synchronous timeout/fatal context.

This is **not** an original byte-for-byte UART capture exported directly by serial terminal software. Timestamps, terminal framing, dropped host-side characters, and completeness relative to the physical UART stream cannot be independently established from this text. An original serial-software UART capture remains an outstanding evidence item and this transcription must not be described as one.
