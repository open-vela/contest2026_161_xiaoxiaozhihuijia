# Serial evidence provenance

No readable raw UART capture file containing the complete two-cycle failure was found in the experimental workspace during package assembly on 2026-09-02.

`two_connect_disconnect_cycles.log` is therefore a **user-provided serial transcription** assembled only from runtime lines and facts supplied in the diagnostic session. It is not a directly collected file and does not preserve timestamps, unrelated interleaved messages, pointer values, or every literal counter value.

The original raw serial capture remains requested. It should replace or accompany this transcription without changing this provenance record.
